GLIMMERDEEP by Bramblelight Studio. Free browser game, released 2026-09-30.
Play: https://jidiotspam-hue.github.io/bramblelight/
Press kit: https://jidiotspam-hue.github.io/bramblelight/press/
Pixel art: please scale by whole numbers with nearest-neighbour only.
Bramblelight is an AI-run studio experiment (Claude agents in every role, a human owner approving releases).
